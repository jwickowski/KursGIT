﻿using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ile masz lat?");
            var wiekText = Console.ReadLine();
            int.TryParse(wiekText, out int wiekInt);
            if (wiekInt >= 18)
            {
                Console.WriteLine("Możesz legalnie kupić piwo w Polsce");
            }
            else
            {
                Console.WriteLine("Nie możesz legalnie kupić piwo w Polsce");
            }
        }
    }
}
